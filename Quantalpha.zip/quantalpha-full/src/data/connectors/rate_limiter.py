import asyncio
from datetime import datetime


class RateLimiter:
    """Token Bucket generique pour tous les connecteurs."""

    def __init__(self, max_requests: int, window_sec: float) -> None:
        self.max_requests = max_requests
        self.window_sec = float(window_sec)
        self._tokens = float(max_requests)
        self._last_refill = datetime.utcnow()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            now = datetime.utcnow()
            elapsed = (now - self._last_refill).total_seconds()
            if elapsed >= self.window_sec:
                self._tokens = float(self.max_requests)
                self._last_refill = now
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return
            wait_sec = self.window_sec - elapsed
            if wait_sec > 0:
                await asyncio.sleep(wait_sec)
                self._tokens = float(self._last_refill) - 1.0
                self._last_refill = datetime.utcnow()
