import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Activity, TrendingUp, BarChart3, Layers } from 'lucide-react'

const PRICE_DATA = Array.from({ length: 50 }, (_, i) => ({
  t: i,
  close: 67200 + Math.sin(i * 0.2) * 1500 + i * 10 + Math.random() * 300,
  ema20: 67200 + Math.sin(i * 0.2) * 1200 + i * 8,
  ema50: 67200 + Math.sin(i * 0.2) * 800 + i * 5,
}))

const INDICATORS = [
  { title: 'RSI', value: '58.4', icon: <Activity size={16} />, color: '#1e2a4a' },
  { title: 'MACD', value: '0.024', icon: <TrendingUp size={16} />, color: '#1e2a4a' },
  { title: 'ATR', value: '142.6', icon: <BarChart3 size={16} />, color: '#1e2a4a' },
  { title: 'VWAP', value: '67,120', icon: <Layers size={16} />, color: '#1e2a4a' },
]

export default function IndicatorsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-navy-700 mb-1">Indicateurs Techniques</h1>
      <p className="text-navy-400 mb-6">Analyse technique avec zero look-ahead bias</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {INDICATORS.map(ind => (
          <div key={ind.title} className="bg-white rounded-lg border border-navy-200 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-navy-400 uppercase tracking-wider">{ind.title}</span>
              <span style={{ color: ind.color }}>{ind.icon}</span>
            </div>
            <div className="font-mono text-xl font-bold text-navy-700">{ind.value}</div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-navy-200 p-4">
        <h4 className="text-sm font-semibold text-navy-600 mb-3">Prix & Moyennes Mobiles</h4>
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={PRICE_DATA}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="t" tick={{ fontSize: 11, fill: '#6b7280' }} hide />
            <YAxis tick={{ fontSize: 11, fill: '#6b7280' }} tickFormatter={v => v.toLocaleString()} />
            <Tooltip contentStyle={{ backgroundColor: '#1e2a4a', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
            <Line type="monotone" dataKey="close" stroke="#1e2a4a" strokeWidth={1.5} dot={false} name="Close" />
            <Line type="monotone" dataKey="ema20" stroke="#b8975a" strokeWidth={1} dot={false} name="EMA 20" />
            <Line type="monotone" dataKey="ema50" stroke="#8da2c9" strokeWidth={1} dot={false} name="EMA 50" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
