import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { LayoutDashboard, Radio, BarChart3, Activity, LineChart } from 'lucide-react'
import DashboardPage from './pages/Dashboard'
import SignalsPage from './pages/Signals'
import BacktestPage from './pages/Backtest'
import IndicatorsPage from './pages/Indicators'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 1000 * 30, retry: 2, refetchOnWindowFocus: false },
  },
})

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/signals', label: 'Signaux', icon: Radio },
  { to: '/backtest', label: 'Backtest', icon: BarChart3 },
  { to: '/indicators', label: 'Indicateurs', icon: Activity },
]

function Layout() {
  return (
    <div className="min-h-screen bg-navy-50">
      <header className="bg-white border-b border-navy-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-navy-500 rounded-lg flex items-center justify-center text-white">
                <LineChart size={18} />
              </div>
              <span className="font-bold text-navy-700 text-lg">QuantAlpha</span>
              <span className="hidden md:inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> API OK
              </span>
            </div>
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map(item => (
                <NavLink key={item.to} to={item.to}
                  className={({ isActive }) =>
                    `flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      isActive ? 'bg-navy-500 text-white shadow-sm' : 'text-navy-400 hover:bg-navy-100 hover:text-navy-600'
                    }`
                  }>
                  <item.icon size={16} /> {item.label}
                </NavLink>
              ))}
            </nav>
          </div>
        </div>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/signals" element={<SignalsPage />} />
          <Route path="/backtest" element={<BacktestPage />} />
          <Route path="/indicators" element={<IndicatorsPage />} />
        </Routes>
      </main>
      <footer className="bg-white border-t border-navy-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between text-sm text-navy-400">
          <span>QuantAlpha Trading Platform v2.0.0</span>
          <span>Python 3.11+ | FastAPI | React 18</span>
        </div>
      </footer>
    </div>
  )
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Layout />
      </BrowserRouter>
    </QueryClientProvider>
  )
}
