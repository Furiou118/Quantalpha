import asyncio
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import httpx
import pandas as pd
from tenacity import retry, stop_after_attempt, wait_exponential
from .base_connector import BaseMarketConnector
from .rate_limiter import RateLimiter

TIMEFRAME_MAP = {"1m": "M1", "5m": "M5", "15m": "M15", "1h": "H1", "4h": "H4", "1d": "D"}
DEFAULT_SYMBOLS = ["EUR_USD", "GBP_USD", "USD_JPY"]


class OandaConnector(BaseMarketConnector):
    NAME = "forex"
    DISPLAY_NAME = "Forex (OANDA)"

    def __init__(self, api_key=None, account=None, env=None):
        self._api_key = api_key or os.environ.get("OANDA_API_KEY", "")
        self._account = account or os.environ.get("OANDA_ACCOUNT", "")
        self._env = (env or os.environ.get("OANDA_ENV", "practice")).lower()
        if not self._api_key or not self._account:
            raise RuntimeError("OANDA_API_KEY et OANDA_ACCOUNT requis")
        base = "https://api-fxpractice.oanda.com" if self._env == "practice" else "https://api-fxtrade.oanda.com"
        self._base_url = f"{base}/v3"
        self._client = None
        self._limiter = RateLimiter(max_requests=100, window_sec=1.0)

    async def __aenter__(self):
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=10.0),
            headers={"Authorization": f"Bearer {self._api_key}", "Accept-Datetime-Format": "RFC3339"},
        )
        return self

    async def __aexit__(self, *_):
        if self._client:
            await self._client.aclose()

    @property
    def symbols(self): return DEFAULT_SYMBOLS
    @property
    def timeframes(self): return list(TIMEFRAME_MAP.keys())

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=5))
    async def fetch_ohlcv(self, symbol, timeframe="1h", since=None, until=None, limit=500):
        if not self._client: raise RuntimeError("Connector non ouvert")
        if timeframe not in TIMEFRAME_MAP: raise ValueError(f"Timeframe inconnu: {timeframe}")
        gran = TIMEFRAME_MAP[timeframe]
        if until is None: until = datetime.utcnow()
        if since is None: since = until - timedelta(days=30)
        await self._limiter.acquire()
        resp = await self._client.get(
            f"{self._base_url}/instruments/{symbol}/candles",
            params={"granularity": gran, "from": since.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "to": until.strftime("%Y-%m-%dT%H:%M:%SZ"), "price": "M", "count": min(limit, 5000)},
        )
        resp.raise_for_status()
        candles = resp.json().get("candles", [])
        rows = [{"timestamp": pd.to_datetime(c["time"]), "open": float(c["mid"]["o"]),
                 "high": float(c["mid"]["h"]), "low": float(c["mid"]["l"]),
                 "close": float(c["mid"]["c"]), "volume": int(c["volume"])}
                for c in candles if c.get("complete")]
        df = pd.DataFrame(rows).set_index("timestamp").sort_index() if rows else pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        return df

    async def fetch_all(self, symbols=None, timeframe="1h", since=None, until=None, limit=500):
        targets = symbols or self.symbols
        results = await asyncio.gather(*[self.fetch_ohlcv(s, timeframe, since, until, limit) for s in targets], return_exceptions=True)
        return {s: r for s, r in zip(targets, results) if not isinstance(r, Exception)}
