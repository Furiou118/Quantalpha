/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#f0f3f8', 100: '#d9e0ed', 200: '#b3c1db',
          300: '#8da2c9', 400: '#6783b7', 500: '#1e2a4a',
          600: '#1a2440', 700: '#161e36', 800: '#12182c', 900: '#0e1222',
        },
        gold: {
          50: '#fdf9f0', 100: '#f9efd3', 200: '#f3df7a',
          300: '#eccf22', 400: '#d4b81e', 500: '#b8975a',
          600: '#9a7f4d', 700: '#7c6640', 800: '#5e4d33', 900: '#403426',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
