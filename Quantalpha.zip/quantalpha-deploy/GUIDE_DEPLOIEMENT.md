# Guide de Deploiement — QuantAlpha

## Options recommandees (par ordre de simplicite)

### 1. Railway (Recommande) — 5 minutes
**URL** : https://railway.app | **Prix** : ~$5-20/mois

```bash
# Installation CLI
npm install -g @railway/cli
railway login

# Deploy
chmod +x scripts/deploy-railway.sh
./scripts/deploy-railway.sh
```

**Avantages** :
- Docker Compose natif
- PostgreSQL + Redis managed en un clic
- HTTPS auto + domaine gratuit
- Auto-deploy depuis GitHub
- CLI simple

**Desavantages** :
- Pas de TimescaleDB managed (utiliser PostgreSQL + extension manuelle)

---

### 2. Render — 10 minutes
**URL** : https://render.com | **Prix** : ~$15-30/mois

```bash
# 1. Fork le repo sur GitHub
# 2. Dashboard Render → New Blueprint → Connecter le repo
# 3. Remplir les variables d'environnement
# 4. Deploy
```

Fichier : `render.yaml` (deja fourni a la racine)

**Avantages** :
- `render.yaml` = infrastructure as code
- PostgreSQL managed + Redis managed
- Static sites gratuits

---

### 3. Fly.io — 10 minutes
**URL** : https://fly.io | **Prix** : ~$2-10/mois

```bash
# Installation
brew install flyctl   # macOS
curl -L https://fly.io/install.sh | sh  # Linux

# Login
fly auth login

# Deploy API
fly launch --config flyio/fly.toml

# Deploy Dashboard
cd dashboard
fly launch --config ../flyio/dashboard.fly.toml

# Redis (Upstash) — gratuit
fly redis create --name quantalpha-redis

# PostgreSQL
fly postgres create --name quantalpha-db
```

**Avantages** :
- Le moins cher
- Edge locations mondiales (latence faible)
- Volumes persistants
- Machine toujours chaude (min_machines_running = 1)

---

### 4. VPS (Hetzner/DigitalOcean) — 20 minutes
**Prix** : ~$5-10/mois

```bash
# Sur le serveur
scp quantalpha-full.tar.gz root@votre-ip:/root/
ssh root@votre-ip
tar xzf quantalpha-full.tar.gz
cd quantalpha
cp .env.example .env
# Editer .env avec les credentials
make dev
```

---

## Comparaison rapide

| Critere | Railway | Render | Fly.io | VPS |
|---------|---------|--------|--------|-----|
| Simplicite | ★★★★★ | ★★★★ | ★★★★ | ★★ |
| Prix | $5-20 | $15-30 | $2-10 | $5-10 |
| Latence | OK | OK | Excellent | Depends |
| Scaling | Auto | Manuel | Auto | Manuel |
| TimescaleDB | Manuell | Manuell | Manuell | Oui |

## Checklist post-deploy

- [ ] Health check `/api/health` retourne 200
- [ ] Swagger `/api/docs` accessible
- [ ] Dashboard charge sans erreur
- [ ] WebSocket `/api/ws/signals` connecte
- [ ] Backtest retourne des resultats
- [ ] Telegram bot repond a `/status`
- [ ] Grafana (si Ext 4) affiche les metriques

## URLs apres deploy

| Service | URL locale | URL Railway | URL Render |
|---------|-----------|-------------|------------|
| Dashboard | http://localhost | https://quantalpha.up.railway.app | https://quantalpha-dashboard.onrender.com |
| API Docs | http://localhost/api/docs | https://quantalpha.up.railway.app/api/docs | https://quantalpha-api.onrender.com/api/docs |
| Grafana | http://localhost:3001 | — | — |
| Prometheus | http://localhost:9090 | — | — |
