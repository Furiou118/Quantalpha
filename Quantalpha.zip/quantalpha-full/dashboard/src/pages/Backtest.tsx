import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'

const EQUITY_DATA = Array.from({ length: 60 }, (_, i) => ({
  day: `J${i + 1}`,
  equity: 10000 + Math.sin(i * 0.15) * 800 + i * 45 + Math.random() * 200 - 100,
}))

const KPI = [
  { label: 'Rendement', value: '+18.6%', positive: true },
  { label: 'Win Rate', value: '62.3%' },
  { label: 'Sharpe', value: '1.84' },
  { label: 'Max DD', value: '-8.2%', positive: false },
]

export default function BacktestPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-navy-700 mb-1">Backtest</h1>
      <p className="text-navy-400 mb-6">Simulation historique avec regles anti-biais strictes</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {KPI.map((k, i) => (
          <div key={i} className="bg-white rounded-xl border border-navy-200 p-3 text-center">
            <div className="text-xs text-navy-400 uppercase">{k.label}</div>
            <div className={`font-mono text-xl font-bold ${k.positive === true ? 'text-green-500' : k.positive === false ? 'text-red-500' : 'text-navy-700'}`}>{k.value}</div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-navy-200 p-4 mb-6">
        <h3 className="text-lg font-semibold text-navy-700 mb-4">Courbe d'Equite</h3>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={EQUITY_DATA}>
            <defs><linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#1e2a4a" stopOpacity={0.3} /><stop offset="95%" stopColor="#1e2a4a" stopOpacity={0} /></linearGradient></defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={{ stroke: '#d1d5db' }} />
            <YAxis tick={{ fontSize: 11, fill: '#6b7280' }} tickFormatter={v => v.toLocaleString()} />
            <Tooltip contentStyle={{ backgroundColor: '#1e2a4a', border: 'none', borderRadius: '8px', color: '#fff' }} />
            <ReferenceLine y={10000} stroke="#b8975a" strokeDasharray="5 5" />
            <Area type="monotone" dataKey="equity" stroke="#1e2a4a" strokeWidth={2} fill="url(#eqGrad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white rounded-xl border border-navy-200 p-4">
        <h3 className="text-lg font-semibold text-navy-700 mb-3">Statistiques detaillees</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-y-3 text-sm">
          <div><span className="text-navy-400">Trades:</span> <span className="font-mono font-semibold">156</span></div>
          <div><span className="text-navy-400">Gagnants:</span> <span className="font-mono font-semibold text-green-500">97</span></div>
          <div><span className="text-navy-400">Perdants:</span> <span className="font-mono font-semibold text-red-500">59</span></div>
          <div><span className="text-navy-400">Profit Factor:</span> <span className="font-mono font-semibold">1.94</span></div>
          <div><span className="text-navy-400">Max DD $:</span> <span className="font-mono font-semibold">-$820</span></div>
          <div><span className="text-navy-400">Return $:</span> <span className="font-mono font-semibold text-green-500">+$1,860</span></div>
        </div>
      </div>
    </div>
  )
}
