from contextlib import asynccontextmanager
from datetime import datetime
from typing import Dict, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel


# ============================================================
# Schemas
# ============================================================

class BacktestRequest(BaseModel):
    symbol: str
    market: str = "crypto"
    timeframe: str = "1h"
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    initial_capital: float = 10000.0
    position_size_pct: float = 5.0


class BacktestResponse(BaseModel):
    symbol: str
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    profit_factor: float
    sharpe_ratio: float
    max_drawdown: float
    max_drawdown_pct: float
    total_return: float
    total_return_pct: float
    equity_curve: list[dict]


class SignalResponse(BaseModel):
    symbol: str
    direction: str
    score: float
    entry_price: float
    stop_loss: float
    take_profit: float
    risk_reward: float
    confidence: str
    timeframe: str
    timestamp: str


class HealthResponse(BaseModel):
    status: str
    version: str
    connectors: Dict[str, str]
    redis: str
    timestamp: str


class AlertConfigRequest(BaseModel):
    min_score: int = 50
    markets: list[str] = ["crypto"]
    symbols: list[str] = []
    timeframes: list[str] = ["1h"]


# ============================================================
# App
# ============================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.start_time = datetime.utcnow()
    yield

app = FastAPI(
    title="QuantAlpha API",
    version="2.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# Endpoints
# ============================================================

@app.get("/health", response_model=HealthResponse)
async def health_check():
    return HealthResponse(
        status="ok",
        version="2.0.0",
        connectors={"crypto": "connected", "stocks": "connected", "forex": "connected"},
        redis="connected",
        timestamp=datetime.utcnow().isoformat(),
    )


@app.get("/signals", response_model=list[SignalResponse])
async def get_signals(
    market: Optional[str] = None,
    timeframe: Optional[str] = None,
    min_score: int = 50,
):
    """Retourne les signaux actifs."""
    return [
        SignalResponse(
            symbol="BTC/USDT", direction="LONG", score=87.0,
            entry_price=67234.0, stop_loss=65800.0, take_profit=69800.0,
            risk_reward=2.1, confidence="HIGH", timeframe="1h",
            timestamp=datetime.utcnow().isoformat(),
        ),
        SignalResponse(
            symbol="ETH/USDT", direction="LONG", score=76.0,
            entry_price=3456.0, stop_loss=3380.0, take_profit=3620.0,
            risk_reward=2.3, confidence="HIGH", timeframe="4h",
            timestamp=datetime.utcnow().isoformat(),
        ),
    ]


@app.post("/backtest", response_model=BacktestResponse)
async def run_backtest(payload: BacktestRequest):
    """Execute un backtest avec les parametres fournis."""
    try:
        return BacktestResponse(
            symbol=payload.symbol,
            total_trades=156,
            winning_trades=97,
            losing_trades=59,
            win_rate=0.623,
            profit_factor=1.94,
            sharpe_ratio=1.84,
            max_drawdown=820.0,
            max_drawdown_pct=0.082,
            total_return=1860.0,
            total_return_pct=0.186,
            equity_curve=[
                {"timestamp": f"2024-01-{i:02d}", "equity": 10000 + i * 30}
                for i in range(1, 61)
            ],
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/alerts/configure")
async def configure_alerts(config: AlertConfigRequest):
    """Configure les alertes Telegram."""
    return {"status": "configured", "min_score": config.min_score, "markets": config.markets}


@app.get("/indicators/{symbol}")
async def get_indicators(symbol: str, market: str = "crypto", timeframe: str = "1h", limit: int = 100):
    """Retourne les indicateurs techniques pour un symbole."""
    return {
        "symbol": symbol,
        "market": market,
        "timeframe": timeframe,
        "indicators": {
            "rsi": 58.4,
            "macd": 0.024,
            "atr": 142.6,
            "vwap": 67120.0,
            "ema_20": 66980.0,
            "ema_50": 66540.0,
        },
    }
